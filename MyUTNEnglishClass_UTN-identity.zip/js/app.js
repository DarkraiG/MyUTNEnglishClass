(function () {
  "use strict";

  /* ============ CONTENT DATA ============ */
  var LEVELS = [
    { code: "A1", name: "Principiante", skill: "Vocabulario esencial", desc: "Saludos, presentaciones y vocabulario cotidiano." },
    { code: "A2", name: "Elemental", skill: "Rutinas diarias", desc: "Describir rutinas, lugares y planes simples." },
    { code: "B1", name: "Intermedio", skill: "Speaking fluido", desc: "Conversaciones sobre estudios, trabajo y opiniones." },
    { code: "B2", name: "Intermedio alto", skill: "Comprensión auditiva", desc: "Escuchar y debatir temas académicos." },
    { code: "C1", name: "Avanzado", skill: "Escritura académica", desc: "Redacción de ensayos y argumentación." },
    { code: "C2", name: "Dominio", skill: "Fluidez profesional", desc: "Presentaciones y comunicación especializada." }
  ];

  /* Cada nivel tiene 2 lecciones. La lección 1 usa opción múltiple;
     la lección 2 mezcla completar-espacio y relacionar, para variar el tipo de ejercicio. */
  var LESSONS = {
    A1: [
      {
        title: "Vocabulario esencial",
        duration: 40,
        captions: [
          { t: 0, text: "Hello! My name is Sofía and I study at UTN." },
          { t: 10, text: "Nice to meet you. Where are you from?" },
          { t: 20, text: "I am from Nezahualcóyotl, in Mexico." },
          { t: 30, text: "Great! Let's practice some everyday words." }
        ],
        quiz: [
          { type: "mcq", q: "¿Cómo se dice 'encantado de conocerte'?", options: ["Nice to meet you", "See you later", "Good night"], correct: 0 },
          { type: "mcq", q: "'Where are you from?' pregunta sobre...", options: ["La edad", "El origen", "La hora"], correct: 1 }
        ]
      },
      {
        title: "Saludos y despedidas",
        duration: 35,
        captions: [
          { t: 0, text: "Good morning! How are you today?" },
          { t: 10, text: "I'm fine, thank you. And you?" },
          { t: 20, text: "See you later, have a nice day!" }
        ],
        quiz: [
          { type: "fill", q: "Completa: 'Good ___, how are you?' (saludo de mañana)", answer: ["morning"] },
          { type: "match", instructions: "Relaciona cada saludo en inglés con su traducción.", pairs: [
            ["Good morning", "Buenos días"],
            ["See you later", "Nos vemos luego"],
            ["Thank you", "Gracias"]
          ]}
        ]
      }
    ],
    A2: [
      {
        title: "Rutinas diarias",
        duration: 40,
        captions: [
          { t: 0, text: "I usually wake up at seven in the morning." },
          { t: 10, text: "Then I have breakfast and go to class." },
          { t: 20, text: "In the afternoon, I study at the library." },
          { t: 30, text: "What is your daily routine like?" }
        ],
        quiz: [
          { type: "mcq", q: "'I usually wake up at seven' describe...", options: ["Un plan futuro", "Una rutina", "Un consejo"], correct: 1 },
          { type: "mcq", q: "¿Qué palabra indica frecuencia?", options: ["Usually", "Library", "Afternoon"], correct: 0 }
        ]
      },
      {
        title: "Lugares y planes",
        duration: 35,
        captions: [
          { t: 0, text: "Next weekend I am going to visit my family." },
          { t: 10, text: "We are planning to go to the park." },
          { t: 20, text: "After that, we will have lunch downtown." }
        ],
        quiz: [
          { type: "fill", q: "Completa: 'I am going ___ visit my family.' (preposición de plan futuro)", answer: ["to"] },
          { type: "match", instructions: "Relaciona el lugar en inglés con su traducción.", pairs: [
            ["Park", "Parque"],
            ["Downtown", "Centro"],
            ["Library", "Biblioteca"]
          ]}
        ]
      }
    ],
    B1: [
      {
        title: "Speaking fluido",
        duration: 45,
        captions: [
          { t: 0, text: "In my opinion, learning English opens many doors." },
          { t: 12, text: "I think practice is more important than perfection." },
          { t: 24, text: "What do you think about studying abroad?" },
          { t: 36, text: "Let's discuss the advantages and disadvantages." }
        ],
        quiz: [
          { type: "mcq", q: "'In my opinion' se usa para...", options: ["Dar un dato", "Expresar un punto de vista", "Hacer una pregunta"], correct: 1 },
          { type: "mcq", q: "Sinónimo de 'advantages'", options: ["Beneficios", "Errores", "Horarios"], correct: 0 }
        ]
      },
      {
        title: "Dar opiniones",
        duration: 38,
        captions: [
          { t: 0, text: "I believe practice makes progress, not perfection." },
          { t: 10, text: "On the other hand, some people prefer studying alone." },
          { t: 20, text: "Personally, I enjoy group discussions." }
        ],
        quiz: [
          { type: "fill", q: "Completa: 'On the other ___, some people prefer studying alone.'", answer: ["hand"] },
          { type: "match", instructions: "Relaciona la frase de opinión con su traducción.", pairs: [
            ["I believe", "Yo creo"],
            ["Personally", "Personalmente"],
            ["On the other hand", "Por otro lado"]
          ]}
        ]
      }
    ],
    B2: [
      {
        title: "Comprensión auditiva",
        duration: 45,
        captions: [
          { t: 0, text: "Today's lecture is about renewable energy sources." },
          { t: 12, text: "Solar and wind power are growing rapidly worldwide." },
          { t: 24, text: "However, storage remains a technical challenge." },
          { t: 36, text: "Let's summarize the key points together." }
        ],
        quiz: [
          { type: "mcq", q: "El tema principal de la conferencia es...", options: ["Energías renovables", "Historia mundial", "Finanzas"], correct: 0 },
          { type: "mcq", q: "'Challenge' en este contexto significa...", options: ["Logro", "Reto", "Premio"], correct: 1 }
        ]
      },
      {
        title: "Debatir temas académicos",
        duration: 40,
        captions: [
          { t: 0, text: "Some researchers argue that storage technology will improve soon." },
          { t: 12, text: "Others remain skeptical about the timeline." },
          { t: 24, text: "Let's weigh both sides of the argument." }
        ],
        quiz: [
          { type: "fill", q: "Completa: 'Let's weigh both ___ of the argument.'", answer: ["sides"] },
          { type: "match", instructions: "Relaciona el término académico con su traducción.", pairs: [
            ["Researchers", "Investigadores"],
            ["Skeptical", "Escéptico"],
            ["Argument", "Argumento"]
          ]}
        ]
      }
    ],
    C1: [
      {
        title: "Escritura académica",
        duration: 45,
        captions: [
          { t: 0, text: "A strong thesis statement guides the entire essay." },
          { t: 12, text: "Each paragraph should support your main argument." },
          { t: 24, text: "Use evidence to strengthen your claims." },
          { t: 36, text: "Finally, the conclusion restates your position." }
        ],
        quiz: [
          { type: "mcq", q: "La tesis de un ensayo debe...", options: ["Ir al final", "Guiar el argumento", "Ser irrelevante"], correct: 1 },
          { type: "mcq", q: "'Evidence' se traduce como...", options: ["Evidencia", "Emoción", "Extensión"], correct: 0 }
        ]
      },
      {
        title: "Redactar con evidencia",
        duration: 38,
        captions: [
          { t: 0, text: "Every claim needs supporting evidence from a reliable source." },
          { t: 12, text: "Avoid vague statements without proof." },
          { t: 24, text: "A clear conclusion restates your main point." }
        ],
        quiz: [
          { type: "fill", q: "Completa: 'Every claim needs supporting ___.'", answer: ["evidence"] },
          { type: "match", instructions: "Relaciona el término de escritura académica con su traducción.", pairs: [
            ["Claim", "Afirmación"],
            ["Source", "Fuente"],
            ["Conclusion", "Conclusión"]
          ]}
        ]
      }
    ],
    C2: [
      {
        title: "Fluidez profesional",
        duration: 45,
        captions: [
          { t: 0, text: "Good morning everyone, thank you for joining this call." },
          { t: 12, text: "Today we will present our quarterly results." },
          { t: 24, text: "Please feel free to ask questions at any point." },
          { t: 36, text: "Let's begin with an overview of the project." }
        ],
        quiz: [
          { type: "mcq", q: "Esta lección simula...", options: ["Una fiesta", "Una presentación profesional", "Una receta"], correct: 1 },
          { type: "mcq", q: "'Feel free to ask' invita a...", options: ["Guardar silencio", "Hacer preguntas", "Terminar la llamada"], correct: 0 }
        ]
      },
      {
        title: "Presentaciones especializadas",
        duration: 40,
        captions: [
          { t: 0, text: "Let's move on to the next slide of our roadmap." },
          { t: 12, text: "As you can see, our results exceeded expectations." },
          { t: 24, text: "I'll now hand it over to my colleague for questions." }
        ],
        quiz: [
          { type: "fill", q: "Completa: 'Let's move on to the next ___.'", answer: ["slide"] },
          { type: "match", instructions: "Relaciona la frase profesional con su traducción.", pairs: [
            ["Roadmap", "Hoja de ruta"],
            ["Exceeded expectations", "Superó las expectativas"],
            ["Hand it over", "Cederle la palabra"]
          ]}
        ]
      }
    ]
  };

  var AVATARS = ["🎓", "🦉", "🦅", "🐺", "🦊", "🐢", "🌵", "⭐"];

  var DELIVERABLES = LEVELS.map(function (lvl) {
    return { code: lvl.code, text: "Entregable " + lvl.code + ": " + lvl.skill };
  });

  /* ============ STATE ============ */
  var STORAGE_KEY = "myutn_progress_v2_" + (window.__UTN_UID__ || "local");
  var THEME_KEY = "myutn_theme";

  function defaultState() {
    return {
      currentLevelIndex: 0,
      completedLessons: [],
      stamps: [],
      profile: { name: "Estudiante UTN", avatar: "🎓" },
      congratsShown: false
    };
  }

  function loadProgress() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        var base = defaultState();
        return {
          currentLevelIndex: typeof parsed.currentLevelIndex === "number" ? parsed.currentLevelIndex : base.currentLevelIndex,
          completedLessons: Array.isArray(parsed.completedLessons) ? parsed.completedLessons : [],
          stamps: Array.isArray(parsed.stamps) ? parsed.stamps : [],
          profile: parsed.profile || base.profile,
          congratsShown: !!parsed.congratsShown
        };
      }
      /* Migración desde versión anterior (myutn_progress_v1) */
      var oldRaw = localStorage.getItem("myutn_progress_v1");
      if (oldRaw) {
        var old = JSON.parse(oldRaw);
        var base2 = defaultState();
        base2.currentLevelIndex = old.currentIndex || 0;
        base2.stamps = old.stamps || [];
        return base2;
      }
    } catch (e) {}
    return defaultState();
  }

  function saveProgress(p) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(p)); } catch (e) {}
    if (typeof window.__UTN_SYNC__ === "function") {
      try { window.__UTN_SYNC__(p); } catch (e) {}
    }
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    var icon = document.getElementById("theme-toggle-icon");
    if (icon) icon.textContent = theme === "dark" ? "☀" : "🌙";
  }

  function loadTheme() {
    var t = "light";
    try { t = localStorage.getItem(THEME_KEY) || "light"; } catch (e) {}
    applyTheme(t);
    return t;
  }

  function saveTheme(t) {
    try { localStorage.setItem(THEME_KEY, t); } catch (e) {}
  }

  var state = loadProgress();
  var currentTheme = loadTheme();
  var activeLevelIndex = state.currentLevelIndex;
  var activeLessonIndex = 0;

  var player = { timer: null, elapsed: 0, speed: 1, playing: false };

  function lessonId(levelCode, lessonIdx) { return levelCode + "-" + lessonIdx; }

  /* ============ NAVIGATION ============ */
  var views = document.querySelectorAll(".view");
  var navLinks = document.querySelectorAll(".main-nav a");

  function goto(name) {
    views.forEach(function (v) { v.hidden = v.dataset.view !== name; });
    navLinks.forEach(function (a) {
      a.classList.toggle("active", a.dataset.nav === name);
    });
    if (name === "leccion") renderLesson(activeLevelIndex, activeLessonIndex);
    if (name === "niveles") renderGates();
    if (name === "progreso") renderProgress();
    window.scrollTo({ top: 0, behavior: "smooth" });
    var nav = document.getElementById("main-nav");
    nav.classList.remove("open");
    document.getElementById("nav-toggle").setAttribute("aria-expanded", "false");
  }

  document.querySelectorAll("[data-goto]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      if (btn.dataset.goto === "leccion") {
        activeLevelIndex = state.currentLevelIndex;
        activeLessonIndex = 0;
      }
      goto(btn.dataset.goto);
    });
  });
  navLinks.forEach(function (a) {
    a.addEventListener("click", function (e) {
      e.preventDefault();
      if (a.dataset.nav === "leccion") {
        activeLevelIndex = state.currentLevelIndex;
        activeLessonIndex = 0;
      }
      goto(a.dataset.nav);
    });
  });

  var navToggle = document.getElementById("nav-toggle");
  navToggle.addEventListener("click", function () {
    var nav = document.getElementById("main-nav");
    var open = nav.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", open ? "true" : "false");
  });

  /* ============ TEMA OSCURO ============ */
  document.getElementById("theme-toggle").addEventListener("click", function () {
    currentTheme = currentTheme === "dark" ? "light" : "dark";
    applyTheme(currentTheme);
    saveTheme(currentTheme);
  });

  /* ============ PERFIL ============ */
  var avatarGrid = document.getElementById("avatar-grid");
  var selectedAvatar = state.profile.avatar;

  function renderAvatarGrid() {
    avatarGrid.innerHTML = "";
    AVATARS.forEach(function (a) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "avatar-option" + (a === selectedAvatar ? " selected" : "");
      b.textContent = a;
      b.addEventListener("click", function () {
        selectedAvatar = a;
        avatarGrid.querySelectorAll(".avatar-option").forEach(function (el) { el.classList.remove("selected"); });
        b.classList.add("selected");
      });
      avatarGrid.appendChild(b);
    });
  }

  function openProfileModal() {
    document.getElementById("profile-name-input").value = state.profile.name;
    selectedAvatar = state.profile.avatar;
    renderAvatarGrid();
    document.getElementById("profile-modal").hidden = false;
  }
  function closeProfileModal() { document.getElementById("profile-modal").hidden = true; }

  document.getElementById("profile-open").addEventListener("click", openProfileModal);
  document.getElementById("profile-cancel").addEventListener("click", closeProfileModal);
  document.getElementById("profile-save").addEventListener("click", function () {
    var name = document.getElementById("profile-name-input").value.trim();
    state.profile.name = name || "Estudiante UTN";
    state.profile.avatar = selectedAvatar;
    saveProgress(state);
    updateProfileUI();
    closeProfileModal();
  });
  document.getElementById("profile-modal").addEventListener("click", function (e) {
    if (e.target.id === "profile-modal") closeProfileModal();
  });

  function updateProfileUI() {
    document.getElementById("profile-chip-avatar").textContent = state.profile.avatar;
    document.getElementById("bp-name").textContent = state.profile.name;
    document.getElementById("bp-avatar").textContent = state.profile.avatar;
  }

  /* ============ BOARDING PASS ============ */
  function updateBoardingPass() {
    var lvl = LEVELS[state.currentLevelIndex];
    var totalLessons = LESSONS[lvl.code].length;
    var doneInLevel = LESSONS[lvl.code].filter(function (_, i) {
      return state.completedLessons.indexOf(lessonId(lvl.code, i)) !== -1;
    }).length;
    document.getElementById("bp-level").textContent = lvl.code + " · " + lvl.name;
    document.getElementById("bp-skill").textContent = lvl.skill;
    document.getElementById("bp-gate").textContent = "Lección " + Math.min(doneInLevel + 1, totalLessons) + " de " + totalLessons;
    document.getElementById("bp-code").textContent = "UTN-" + lvl.code + "-0" + (doneInLevel + 1);
    var pct = Math.round((state.stamps.length / LEVELS.length) * 100);
    document.getElementById("bp-progress-fill").style.width = Math.max(6, pct) + "%";
    updateProfileUI();
  }

  /* ============ GATES / NIVELES ============ */
  function renderGates() {
    var grid = document.getElementById("gates-grid");
    grid.innerHTML = "";
    LEVELS.forEach(function (lvl, i) {
      var earned = state.stamps.indexOf(lvl.code) !== -1;
      var locked = i > state.currentLevelIndex;
      var statusClass = earned ? "done" : (locked ? "locked" : "active");
      var statusText = earned ? "completo" : (locked ? "bloqueado" : "en curso");
      var lessons = LESSONS[lvl.code];

      var card = document.createElement("article");
      card.className = "gate-card" + (locked ? " locked" : "");

      var pillsHtml = lessons.map(function (les, li) {
        var done = state.completedLessons.indexOf(lessonId(lvl.code, li)) !== -1;
        return '<button class="lesson-pill' + (done ? " done" : "") + '" data-level="' + i + '" data-lesson="' + li + '" ' + (locked ? "disabled" : "") + '>' +
          (done ? "✓ " : "") + (li + 1) + "</button>";
      }).join("");

      card.innerHTML =
        '<div class="gate-top">' +
          '<span class="gate-code">' + lvl.code + '</span>' +
          '<span class="gate-status ' + statusClass + '">' + statusText + '</span>' +
        '</div>' +
        '<p class="gate-name">' + lvl.name + '</p>' +
        '<p class="gate-desc">' + lvl.desc + '</p>' +
        '<div class="lesson-pills">' + pillsHtml + '</div>';

      if (!locked) {
        card.querySelectorAll(".lesson-pill").forEach(function (btn) {
          btn.addEventListener("click", function () {
            activeLevelIndex = parseInt(btn.dataset.level, 10);
            activeLessonIndex = parseInt(btn.dataset.lesson, 10);
            goto("leccion");
          });
        });
      }
      grid.appendChild(card);
    });
  }

  /* ============ LECCIÓN / TABS ============ */
  function renderLessonTabs(levelIdx, lessonIdx) {
    var lvl = LEVELS[levelIdx];
    var lessons = LESSONS[lvl.code];
    var tabsEl = document.getElementById("lesson-tabs");
    tabsEl.innerHTML = "";
    lessons.forEach(function (les, i) {
      var done = state.completedLessons.indexOf(lessonId(lvl.code, i)) !== -1;
      var tab = document.createElement("button");
      tab.className = "lesson-tab" + (i === lessonIdx ? " active" : "") + (done ? " done" : "");
      tab.textContent = (done ? "✓ " : "") + "Lección " + (i + 1);
      tab.addEventListener("click", function () {
        activeLessonIndex = i;
        renderLesson(levelIdx, i);
      });
      tabsEl.appendChild(tab);
    });
  }

  /* ============ PLAYER ============ */
  function stopPlayer() {
    if (player.timer) clearInterval(player.timer);
    player.timer = null;
    player.playing = false;
    player.elapsed = 0;
    document.getElementById("player-play-icon").textContent = "▶";
    document.getElementById("player-fill").style.width = "0%";
    document.getElementById("player-current").textContent = "0:00";
  }

  function formatTime(sec) {
    var m = Math.floor(sec / 60);
    var s = Math.floor(sec % 60);
    return m + ":" + (s < 10 ? "0" : "") + s;
  }

  function renderLesson(levelIdx, lessonIdx) {
    var lvl = LEVELS[levelIdx];
    var lesson = LESSONS[lvl.code][lessonIdx];
    document.getElementById("leccion-eyebrow").textContent = "Nivel " + lvl.code + " · Lección " + (lessonIdx + 1) + " de " + LESSONS[lvl.code].length;
    document.getElementById("leccion-title").textContent = lesson.title;
    document.getElementById("leccion-desc").textContent = "Escucha el audio, sigue la transcripción y resuelve el quiz para sellar tu avance.";
    document.getElementById("player-total").textContent = formatTime(lesson.duration);
    document.getElementById("player-caption").textContent = "Presiona reproducir para ver la transcripción en vivo.";
    stopPlayer();
    renderLessonTabs(levelIdx, lessonIdx);
    renderQuiz(levelIdx, lessonIdx, lesson);
  }

  var playBtn = document.getElementById("player-play");
  playBtn.addEventListener("click", function () {
    var lvl = LEVELS[activeLevelIndex];
    var lesson = LESSONS[lvl.code][activeLessonIndex];
    if (player.playing) {
      clearInterval(player.timer);
      player.playing = false;
      document.getElementById("player-play-icon").textContent = "▶";
      return;
    }
    player.playing = true;
    document.getElementById("player-play-icon").textContent = "❙❙";
    player.timer = setInterval(function () {
      player.elapsed += 1 * player.speed;
      if (player.elapsed >= lesson.duration) {
        player.elapsed = lesson.duration;
        stopPlayer();
      }
      var pct = (player.elapsed / lesson.duration) * 100;
      document.getElementById("player-fill").style.width = pct + "%";
      document.getElementById("player-current").textContent = formatTime(player.elapsed);

      var current = lesson.captions[0].text;
      lesson.captions.forEach(function (c) {
        if (player.elapsed >= c.t) current = c.text;
      });
      document.getElementById("player-caption").textContent = current;
    }, 1000);
  });

  document.getElementById("player-speed-select").addEventListener("change", function (e) {
    player.speed = parseFloat(e.target.value);
  });

  /* ============ QUIZ (mcq / fill / match) ============ */
  function renderQuiz(levelIdx, lessonIdx, lesson) {
    var levelCode = LEVELS[levelIdx].code;
    var body = document.getElementById("quiz-body");
    var resultBox = document.getElementById("quiz-result");
    resultBox.hidden = true;
    body.innerHTML = "";
    var answered = new Array(lesson.quiz.length).fill(false);
    var correctCount = 0;

    function checkAllAnswered() {
      if (answered.every(Boolean)) {
        var scoreText = "Obtuviste " + correctCount + " de " + lesson.quiz.length + " correctas.";
        document.getElementById("quiz-score-text").textContent = scoreText;
        resultBox.hidden = false;
      }
    }

    lesson.quiz.forEach(function (q, qi) {
      var qEl = document.createElement("div");
      qEl.className = "quiz-q";

      if (q.type === "fill") {
        qEl.innerHTML =
          "<p>" + (qi + 1) + ". " + q.q + "</p>" +
          '<div class="fill-row">' +
            '<input type="text" class="fill-input" data-qi="' + qi + '" autocomplete="off" placeholder="Escribe tu respuesta">' +
            '<button class="btn btn-primary fill-check" data-qi="' + qi + '">Verificar</button>' +
          "</div>" +
          '<p class="fill-feedback" id="fill-feedback-' + qi + '"></p>';
        body.appendChild(qEl);

        var checkFill = function () {
          if (answered[qi]) return;
          var input = qEl.querySelector(".fill-input");
          var val = input.value.trim().toLowerCase();
          var ok = q.answer.some(function (a) { return a.toLowerCase() === val; });
          answered[qi] = true;
          input.disabled = true;
          qEl.querySelector(".fill-check").disabled = true;
          var fb = qEl.querySelector(".fill-feedback");
          if (ok) {
            correctCount++;
            input.classList.add("correct");
            fb.textContent = "¡Correcto!";
            fb.className = "fill-feedback ok";
          } else {
            input.classList.add("incorrect");
            fb.textContent = "Respuesta esperada: " + q.answer[0];
            fb.className = "fill-feedback bad";
          }
          checkAllAnswered();
        };
        qEl.querySelector(".fill-check").addEventListener("click", checkFill);
        qEl.querySelector(".fill-input").addEventListener("keydown", function (e) {
          if (e.key === "Enter") checkFill();
        });

      } else if (q.type === "match") {
        var leftItems = q.pairs.map(function (p, i) { return { text: p[0], idx: i }; });
        var rightItems = q.pairs.map(function (p, i) { return { text: p[1], idx: i }; });
        rightItems = shuffleArray(rightItems.slice());

        var leftHtml = leftItems.map(function (it) {
          return '<button class="match-item" data-side="left" data-idx="' + it.idx + '">' + it.text + "</button>";
        }).join("");
        var rightHtml = rightItems.map(function (it) {
          return '<button class="match-item" data-side="right" data-idx="' + it.idx + '">' + it.text + "</button>";
        }).join("");

        qEl.innerHTML =
          "<p>" + (qi + 1) + ". " + (q.instructions || "Relaciona los conceptos.") + "</p>" +
          '<div class="match-columns">' +
            '<div class="match-col">' + leftHtml + "</div>" +
            '<div class="match-col">' + rightHtml + "</div>" +
          "</div>";
        body.appendChild(qEl);

        var selectedLeft = null;
        var matchedCount = 0;
        qEl.querySelectorAll(".match-item").forEach(function (btn) {
          btn.addEventListener("click", function () {
            if (btn.classList.contains("matched")) return;
            if (btn.dataset.side === "left") {
              qEl.querySelectorAll('.match-item[data-side="left"]').forEach(function (b) { b.classList.remove("selected"); });
              selectedLeft = btn;
              btn.classList.add("selected");
            } else if (selectedLeft) {
              var ok = selectedLeft.dataset.idx === btn.dataset.idx;
              if (ok) {
                selectedLeft.classList.add("matched");
                btn.classList.add("matched");
                selectedLeft.classList.remove("selected");
                selectedLeft.disabled = true;
                btn.disabled = true;
                matchedCount++;
                selectedLeft = null;
                if (matchedCount === q.pairs.length && !answered[qi]) {
                  answered[qi] = true;
                  correctCount++;
                  checkAllAnswered();
                }
              } else {
                btn.classList.add("shake");
                selectedLeft.classList.add("shake");
                setTimeout(function () {
                  btn.classList.remove("shake");
                  if (selectedLeft) selectedLeft.classList.remove("shake", "selected");
                  selectedLeft = null;
                }, 420);
              }
            }
          });
        });

      } else {
        /* mcq (por defecto) */
        var optsHtml = q.options.map(function (opt, oi) {
          return '<button class="quiz-option" data-qi="' + qi + '" data-oi="' + oi + '">' + opt + "</button>";
        }).join("");
        qEl.innerHTML = "<p>" + (qi + 1) + ". " + q.q + '</p><div class="quiz-options">' + optsHtml + "</div>";
        body.appendChild(qEl);
      }
    });

    body.querySelectorAll(".quiz-option").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var qi = parseInt(btn.dataset.qi, 10);
        if (answered[qi]) return;
        answered[qi] = true;
        var q = lesson.quiz[qi];
        var oi = parseInt(btn.dataset.oi, 10);
        var group = body.querySelectorAll('.quiz-option[data-qi="' + qi + '"]');
        group.forEach(function (g) {
          var gOi = parseInt(g.dataset.oi, 10);
          if (gOi === q.correct) g.classList.add("correct");
          else if (gOi === oi) g.classList.add("incorrect");
          g.disabled = true;
        });
        if (oi === q.correct) correctCount++;
        checkAllAnswered();
      });
    });

    document.getElementById("quiz-next-btn").onclick = function () {
      var lid = lessonId(levelCode, lessonIdx);
      if (state.completedLessons.indexOf(lid) === -1) state.completedLessons.push(lid);

      var levelLessons = LESSONS[levelCode];
      var allLevelLessonsDone = levelLessons.every(function (_, i) {
        return state.completedLessons.indexOf(lessonId(levelCode, i)) !== -1;
      });

      if (allLevelLessonsDone && state.stamps.indexOf(levelCode) === -1) {
        state.stamps.push(levelCode);
        if (levelIdx === state.currentLevelIndex && state.currentLevelIndex < LEVELS.length - 1) {
          state.currentLevelIndex += 1;
        }
      }
      saveProgress(state);
      updateBoardingPass();

      if (state.stamps.length === LEVELS.length && !state.congratsShown) {
        state.congratsShown = true;
        saveProgress(state);
        goto("niveles");
        setTimeout(openCongratsModal, 300);
      } else {
        goto("niveles");
      }
    };
  }

  function shuffleArray(arr) {
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
    }
    return arr;
  }

  /* ============ PROGRESO ============ */
  function renderProgress() {
    var lvl = LEVELS[state.currentLevelIndex];
    document.getElementById("summary-level").textContent = lvl.code;
    document.getElementById("summary-stamps").textContent = state.stamps.length;
    var pct = Math.round((state.stamps.length / LEVELS.length) * 100);
    document.getElementById("summary-percent").textContent = pct + "%";

    var passport = document.getElementById("passport-stamps");
    passport.innerHTML = "";
    LEVELS.forEach(function (l) {
      var earned = state.stamps.indexOf(l.code) !== -1;
      var s = document.createElement("div");
      s.className = "stamp" + (earned ? " earned" : "");
      s.textContent = l.code;
      passport.appendChild(s);
    });

    var list = document.getElementById("deliverables-list");
    list.innerHTML = "";
    DELIVERABLES.forEach(function (d) {
      var done = state.stamps.indexOf(d.code) !== -1;
      var li = document.createElement("li");
      li.innerHTML = '<span class="deliverable-check' + (done ? " done" : "") + '">' + (done ? "✓" : "") + "</span><span>" + d.text + "</span>";
      list.appendChild(li);
    });

    var complete = state.stamps.length === LEVELS.length;
    var certBtn = document.getElementById("certificate-btn");
    var certDesc = document.getElementById("certificate-desc");
    certBtn.disabled = !complete;
    certDesc.textContent = complete
      ? "¡Completaste los seis niveles! Descarga tu certificado del programa."
      : "Completa los seis niveles (A1 a C2) para desbloquear tu certificado descargable.";
  }

  /* ============ CERTIFICADO ============ */
  function drawCertificate() {
    var canvas = document.getElementById("certificate-canvas");
    var ctx = canvas.getContext("2d");
    var w = canvas.width, h = canvas.height;

    ctx.fillStyle = "#FAFBFA";
    ctx.fillRect(0, 0, w, h);

    /* franja tricolor superior */
    var stripeH = 16;
    ctx.fillStyle = "#0C4EB8"; ctx.fillRect(0, 0, w / 3, stripeH);
    ctx.fillStyle = "#E2141B"; ctx.fillRect(w / 3, 0, w / 3, stripeH);
    ctx.fillStyle = "#0C9C61"; ctx.fillRect((w / 3) * 2, 0, w / 3, stripeH);
    ctx.fillStyle = "#0C4EB8"; ctx.fillRect(0, h - stripeH, w / 3, stripeH);
    ctx.fillStyle = "#E2141B"; ctx.fillRect(w / 3, h - stripeH, w / 3, stripeH);
    ctx.fillStyle = "#0C9C61"; ctx.fillRect((w / 3) * 2, h - stripeH, w / 3, stripeH);

    /* borde */
    ctx.strokeStyle = "#121212";
    ctx.lineWidth = 3;
    ctx.strokeRect(24, 40, w - 48, h - 80);

    /* sello circular */
    var cx = w - 140, cy = h - 160, r = 70;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fillStyle = "#0C4EB8"; ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.78, 0, Math.PI * 2); ctx.fillStyle = "#FAFBFA"; ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.78, 0, Math.PI * 2); ctx.lineWidth = 6; ctx.strokeStyle = "#E2141B"; ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.55, 0, Math.PI * 2); ctx.fillStyle = "#0C9C61"; ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.4, 0, Math.PI * 2); ctx.fillStyle = "#FAFBFA"; ctx.fill();
    ctx.fillStyle = "#0C4EB8";
    ctx.font = "bold 22px 'Space Grotesk', sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("UT", cx, cy + 2);

    /* textos */
    ctx.fillStyle = "#565B5E";
    ctx.font = "13px 'Space Grotesk', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("UNIVERSIDAD TECNOLÓGICA DE NEZAHUALCÓYOTL · EXCELENCIA ACADÉMICA", w / 2, 90);

    ctx.fillStyle = "#0C4EB8";
    ctx.font = "bold 40px 'Space Grotesk', sans-serif";
    ctx.fillText("Certificado de finalización", w / 2, 150);

    ctx.fillStyle = "#16181A";
    ctx.font = "17px 'Source Serif 4', Georgia, serif";
    ctx.fillText("Se certifica que", w / 2, 230);

    ctx.fillStyle = "#E2141B";
    ctx.font = "bold 34px 'Space Grotesk', sans-serif";
    ctx.fillText(state.profile.name, w / 2, 285);

    ctx.fillStyle = "#16181A";
    ctx.font = "17px 'Source Serif 4', Georgia, serif";
    wrapText(ctx, "ha completado exitosamente el programa de inglés MyUTNEnglishClass,", w / 2, 335, w - 200, 24);
    wrapText(ctx, "cursando los seis niveles del Marco Común Europeo, de A1 a C2.", w / 2, 359, w - 200, 24);

    ctx.fillStyle = "#565B5E";
    ctx.font = "14px 'Space Grotesk', sans-serif";
    var today = new Date();
    var fecha = today.toLocaleDateString("es-MX", { year: "numeric", month: "long", day: "numeric" });
    ctx.fillText("Emitido el " + fecha, w / 2, 430);

    ctx.textAlign = "left";
    ctx.fillStyle = "#16181A";
    ctx.font = "13px 'Space Grotesk', sans-serif";
    ctx.fillText("Programa de Servicio Social", 70, h - 100);
    ctx.fillText("Educación, arte, cultura y deporte", 70, h - 80);
  }

  function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
    var words = text.split(" ");
    var line = "";
    var lines = [];
    words.forEach(function (word) {
      var test = line + word + " ";
      if (ctx.measureText(test).width > maxWidth && line !== "") {
        lines.push(line);
        line = word + " ";
      } else {
        line = test;
      }
    });
    lines.push(line);
    lines.forEach(function (l, i) { ctx.fillText(l.trim(), x, y + i * lineHeight); });
  }

  document.getElementById("certificate-btn").addEventListener("click", function () {
    drawCertificate();
    var canvas = document.getElementById("certificate-canvas");
    var link = document.createElement("a");
    link.download = "Certificado-MyUTNEnglishClass-" + state.profile.name.replace(/\s+/g, "_") + ".png";
    link.href = canvas.toDataURL("image/png");
    link.click();
  });

  /* ============ MODAL FELICITACIÓN ============ */
  function openCongratsModal() { document.getElementById("congrats-modal").hidden = false; }
  function closeCongratsModal() { document.getElementById("congrats-modal").hidden = true; }
  document.getElementById("congrats-close").addEventListener("click", function () {
    closeCongratsModal();
    goto("progreso");
  });

  /* ============ INIT ============ */
  updateBoardingPass();
  updateProfileUI();
  goto("inicio");
})();
